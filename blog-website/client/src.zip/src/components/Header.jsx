import logo from "../assets/logo.png";

export default function Header() {
    return (
        <div id="Header">
            <img src={logo} alt="Blog Logo" width="200" />
        </div>
    );
}